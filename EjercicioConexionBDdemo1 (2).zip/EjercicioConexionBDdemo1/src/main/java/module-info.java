module ni.uam.edu.ejercicioconexionbddemo {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires jdk.jdi;

    opens ni.uam.edu.ejercicioconexionbd.model to javafx.base;
    opens ni.uam.edu.ejercicioconexionbd to javafx.fxml;
    exports ni.uam.edu.ejercicioconexionbd.controller to javafx.fxml;
    opens ni.uam.edu.ejercicioconexionbd.controller to javafx.fxml;
}