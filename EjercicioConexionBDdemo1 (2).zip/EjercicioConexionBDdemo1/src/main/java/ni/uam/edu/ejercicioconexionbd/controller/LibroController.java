package ni.uam.edu.ejercicioconexionbd.controller;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import ni.uam.edu.ejercicioconexionbd.connection.DatabaseConnection;
import ni.uam.edu.ejercicioconexionbd.model.Libro;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LibroController {

    @FXML
    private TextField txtTitulo;

    @FXML
    private TextField txtAutor;

    @FXML
    private TextField txtPrecio;

    @FXML
    private TextField txtStock;

    @FXML
    private ComboBox<String> cbCategoria;

    @FXML
    private TableView<Libro> tblLibros;

    @FXML
    private TableColumn<Libro, String> colId;

    @FXML
    private TableColumn<Libro, String> colTitulo;

    @FXML
    private TableColumn<Libro, String> colAutor;

    @FXML
    private TableColumn<Libro, String> colCategoria;

    @FXML
    private TableColumn<Libro, Double> colPrecio;

    @FXML
    private TableColumn<Libro, Integer> colStock;

    @FXML
    private Button btnGuardar;

    @FXML
    private Button btnLimpiar;

    @FXML
    private Button btnActualizar;

    private final ObservableList<Libro> listaLibros = FXCollections.observableArrayList();

    @FXML
    public void initialize(){
        configurarTabla();
        configurarComboBox();
        cargarLibros();
    }

    //Definir el metodo
    private void configurarTabla(){
        colId.setCellValueFactory(new PropertyValueFactory<>("Id"));
        colTitulo.setCellValueFactory(new PropertyValueFactory<>("Titulo"));
        colAutor.setCellValueFactory(new PropertyValueFactory<>("Autor"));
        colCategoria.setCellValueFactory(new PropertyValueFactory<>("Categoria"));
        colPrecio.setCellValueFactory(new PropertyValueFactory<>("Precio"));
        colStock.setCellValueFactory(new PropertyValueFactory<>("Stock"));
    }

    //Metodo encargado de cargar datos por defecto del ComboBox
    private void configurarComboBox(){
        cbCategoria.getItems().clear();
        cbCategoria.getItems().addAll("Tecologia", "Ciencia", "Ficcion", "Filosofia");
    }

    @FXML
    private void cargarLibros(){
        listaLibros.clear();

        String sql = "SELECT * FROM Libro";

        try(
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery();
                ){
            while (resultSet.next()){
                Libro libro = new Libro();
                libro.setId(resultSet.getInt("Id"));
                libro.setTitulo(resultSet.getString("Titulo"));
                libro.setAutor(resultSet.getString("Autor"));
                libro.setCategoria(resultSet.getString("Categoria"));
                libro.setPrecio(resultSet.getDouble("Precio"));
                libro.setStock(resultSet.getInt("Stock"));
                listaLibros.add(libro);
            }
        } catch (SQLException ex){
            ex.printStackTrace();
        }
    }

    @FXML
    private void guardarLibro() {

        if (!validarCampos()) {
            return;
        }

        String sql =
                "INSERT INTO Libro " +
                        "(titulo, autor, categoria, precio, stock) " +
                        "VALUES (?, ?, ?, ?, ?)";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(1, txtTitulo.getText());
            statement.setString(2, txtAutor.getText());
            statement.setString(3, cbCategoria.getValue());
            statement.setDouble(
                    4,
                    Double.parseDouble(txtPrecio.getText())
            );
            statement.setInt(
                    5,
                    Integer.parseInt(txtStock.getText())
            );

            statement.executeUpdate();

            mostrarAlerta(
                    Alert.AlertType.INFORMATION,
                    "Registro almacenado",
                    "Libro registrado",
                    "El libro se ha almacenado exitosamente"
            );

            cargarLibros();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
        }
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String encabezado, String mensaje){
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(encabezado);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private boolean validarCampos() {
        return true;
    }
}
